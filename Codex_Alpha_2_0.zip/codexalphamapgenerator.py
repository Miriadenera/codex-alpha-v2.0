import pandas as pd
import os

print("\n=== Codex Alpha – Terminale Informazionale ===")
print(" Teoria unificata tra Relatività Generale e Meccanica Quantistica")
print(" Autore: Davide Cadelano\n")

filename = "pulsars_50_real.csv"
if not os.path.exists(filename):
    print(f"⚠️  Errore: il file '{filename}' non è stato trovato nella directory corrente.")
    exit()

df = pd.read_csv(filename)
df = df.dropna(subset=['F0', 'F1'])

# 🔁 Usa nome compatibile
df['gradK'] = (df['F1'].astype(float).abs()) / df['F0'].astype(float)
df_sorted = df.sort_values(by='gradK', ascending=False)

print("  > Analisi su 45 pulsar reali: Calcolo del gradiente di coerenza informazionale ∇𝒦 = |F1 / F0|")
print("  > Ordinamento decrescente secondo ∇𝒦\n")

for i, row in enumerate(df_sorted.head(45).itertuples(), 1):
    name = getattr(row, 'PSRJ', f"Pulsar_{i}")
    F0 = getattr(row, 'F0')
    F1 = getattr(row, 'F1')
    grad_k = getattr(row, 'gradK')
    
    print(f"{i:02d}. Pulsar: {name:<18} | F0 = {F0:.5f} Hz | F1 = {F1:.5e} Hz/s | ∇𝒦 = {grad_k:.6e}")

print("\n== Fine elaborazione ==")
